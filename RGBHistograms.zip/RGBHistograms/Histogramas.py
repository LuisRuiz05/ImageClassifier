import numpy as np 
import cv2
import json

def featureRedHistogram(image):
    featureHistogram = np.zeros(256)
    for i in range(0,image.shape[0]):
        for j in range(0,image.shape[1]):
            featureHistogram[int(image[i,j,0])]+=1
    return featureHistogram

def featureGreenHistogram(image):
    featureHistogram = np.zeros(256)
    for i in range(0,image.shape[0]):
        for j in range(0,image.shape[1]):
            featureHistogram[int(image[i,j,1])]+=1
    return featureHistogram

def featureBlueHistogram(image):
    featureHistogram = np.zeros(256)
    for i in range(0,image.shape[0]):
        for j in range(0,image.shape[1]):
            featureHistogram[int(image[i,j,2])]+=1
    return featureHistogram


file = 'TestImages/simpsons_1.png'
image = cv2.imread(file, cv2.IMREAD_COLOR)

histogram = featureBlueHistogram(image)

Size = []
i = 0;
for value in histogram:
    Size.append({
        "name": i,
        "height": int(value)
    })
    i+=1

with open("BlueHistogram.json", "w") as outfile:
    json.dump(Size, outfile, indent=3,  separators=(',',': '))